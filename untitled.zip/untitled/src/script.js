// Game Data
const GAME = {
    player: {
        name: "PLAYER_1",
        level: 25,
        gold: 10000,
        character: null,
        kills: 0,
        wins: 0
    },
    
    characters: [
        {
            id: "commando",
            name: "COMMANDO",
            icon: "💂",
            color: "#ff4655",
            ability: "EXTRA DAMAGE",
            health: 200,
            speed: 5.5,
            damage: 1.2
        },
        {
            id: "medic",
            name: "MEDIC",
            icon: "👨‍⚕️",
            color: "#1e90ff",
            ability: "HEAL OVER TIME",
            health: 180,
            speed: 5.8,
            damage: 1.0
        },
        {
            id: "scout",
            name: "SCOUT",
            icon: "🏃",
            color: "#2ecc71",
            ability: "FASTER SPEED",
            health: 160,
            speed: 6.2,
            damage: 0.9
        },
        {
            id: "sniper",
            name: "SNIPER",
            icon: "🎯",
            color: "#9b59b6",
            ability: "SNIPER BONUS",
            health: 170,
            speed: 5.3,
            damage: 1.3
        },
        {
            id: "tank",
            name: "TANK",
            icon: "🛡️",
            color: "#e67e22",
            ability: "DAMAGE REDUCTION",
            health: 220,
            speed: 5.0,
            damage: 1.1
        },
        {
            id: "agile",
            name: "AGILE",
            icon: "🤸",
            color: "#e74c3c",
            ability: "FASTER RELOAD",
            health: 175,
            speed: 6.0,
            damage: 1.0
        }
    ],
    
    weapons: [
        { id: "ak47", name: "AK-47", damage: 35, ammo: 30, price: 500 },
        { id: "m416", name: "M416", damage: 30, ammo: 30, price: 400 },
        { id: "awm", name: "AWM", damage: 85, ammo: 5, price: 1000 },
        { id: "ump", name: "UMP9", damage: 25, ammo: 25, price: 300 }
    ],
    
    state: {
        running: false,
        playersAlive: 50,
        zoneTime: 270,
        soundEnabled: true,
        vibrationEnabled: true
    }
};

// Global Variables
let currentScreen = "loadingScreen";
let selectedCharacter = GAME.characters[0];
let gameEngine = null;

// Initialize Game
window.onload = function() {
    initLoading();
    setupControls();
};

// Loading Screen
function initLoading() {
    let progress = 0;
    const loadingInterval = setInterval(() => {
        progress += 2;
        document.getElementById('loadingProgress').style.width = `${progress}%`;
        
        const texts = [
            "Loading assets...",
            "Preparing battle...",
            "Setting up players...",
            "Almost ready...",
            "Let's battle!"
        ];
        
        const textIndex = Math.floor(progress / 20);
        if (textIndex < texts.length) {
            document.getElementById('loadingText').textContent = texts[textIndex];
        }
        
        if (progress >= 100) {
            clearInterval(loadingInterval);
            setTimeout(() => {
                showScreen('mainMenu');
                loadCharacters();
            }, 500);
        }
    }, 30);
}

// Screen Management
function showScreen(screenId) {
    // Hide all screens
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    
    // Show requested screen
    document.getElementById(screenId).classList.add('active');
    currentScreen = screenId;
    
    // Stop game if leaving game screen
    if (screenId !== 'gameScreen' && gameEngine) {
        gameEngine.stop();
    }
}

// Character System
function loadCharacters() {
    const container = document.getElementById('characterGrid');
    container.innerHTML = '';
    
    GAME.characters.forEach(char => {
        const card = document.createElement('div');
        card.className = 'character-card';
        if (char.id === selectedCharacter.id) {
            card.classList.add('selected');
        }
        
        card.innerHTML = `
            <div class="char-icon" style="color: ${char.color}">${char.icon}</div>
            <div class="char-name" style="color: ${char.color}">${char.name}</div>
            <div class="char-ability">${char.ability}</div>
            <div style="margin-top: 10px; font-size: 0.8rem; color: #b0b7c3">
                HP: ${char.health} | SPD: ${char.speed}
            </div>
        `;
        
        card.onclick = () => selectCharacter(char);
        container.appendChild(card);
    });
    
    updateCharacterDetails();
}

function selectCharacter(char) {
    // Deselect all
    document.querySelectorAll('.character-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // Select clicked
    event.currentTarget.classList.add('selected');
    selectedCharacter = char;
    GAME.player.character = char;
    updateCharacterDetails();
}

function updateCharacterDetails() {
    document.getElementById('selectedName').textContent = selectedCharacter.name;
    document.getElementById('selectedAbility').textContent = selectedCharacter.ability;
    document.getElementById('selectedHealth').textContent = selectedCharacter.health;
    document.getElementById('selectedSpeed').textContent = selectedCharacter.speed;
    document.getElementById('selectedDamage').textContent = selectedCharacter.damage + "x";
}

// Game Engine
class GameEngine {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.canvas.width = 500;
        this.canvas.height = 900;
        
        this.keys = {};
        this.enemies = [];
        this.bullets = [];
        this.gameTime = 0;
        this.zoneRadius = 400;
        
        // Joystick
        this.joystickActive = false;
        this.joystickX = 0;
        this.joystickY = 0;
        
        // Player
        this.player = {
            x: this.canvas.width / 2,
            y: this.canvas.height - 150,
            width: 40,
            height: 80,
            health: selectedCharacter.health,
            maxHealth: selectedCharacter.health,
            kills: 0,
            character: selectedCharacter,
            weapon: { name: "AK-47", damage: 35, ammo: 30, maxAmmo: 30 },
            reloading: false,
            speed: selectedCharacter.speed
        };
        
        this.init();
    }
    
    init() {
        // Create enemies
        for (let i = 0; i < 49; i++) {
            const randomChar = GAME.characters[Math.floor(Math.random() * GAME.characters.length)];
            this.enemies.push({
                x: Math.random() * (this.canvas.width - 100) + 50,
                y: Math.random() * (this.canvas.height - 300) + 50,
                width: 40,
                height: 80,
                health: randomChar.health,
                alive: true,
                speed: randomChar.speed,
                character: randomChar
            });
        }
        
        this.setupJoystick();
        this.updateUI();
    }
    
    setupJoystick() {
        const joystick = document.getElementById('joystick');
        const joystickInner = document.getElementById('joystickInner');
        
        joystick.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.joystickActive = true;
        });
        
        joystick.addEventListener('touchmove', (e) => {
            e.preventDefault();
            if (this.joystickActive) {
                const rect = joystick.getBoundingClientRect();
                const touch = e.touches[0];
                
                let x = touch.clientX - rect.left - rect.width / 2;
                let y = touch.clientY - rect.top - rect.height / 2;
                
                // Limit movement
                const distance = Math.sqrt(x * x + y * y);
                const maxDistance = rect.width / 2 - 25;
                
                if (distance > maxDistance) {
                    x = (x / distance) * maxDistance;
                    y = (y / distance) * maxDistance;
                }
                
                // Update joystick visual
                joystickInner.style.transform = `translate(${x}px, ${y}px)`;
                
                // Store normalized values
                this.joystickX = x / maxDistance;
                this.joystickY = y / maxDistance;
            }
        });
        
        joystick.addEventListener('touchend', (e) => {
            e.preventDefault();
            this.joystickActive = false;
            joystickInner.style.transform = 'translate(-50%, -50%)';
            this.joystickX = 0;
            this.joystickY = 0;
        });
    }
    
    start() {
        GAME.state.running = true;
        this.gameLoop();
    }
    
    stop() {
        GAME.state.running = false;
    }
    
    gameLoop() {
        if (!GAME.state.running) return;
        
        this.update();
        this.render();
        
        requestAnimationFrame(() => this.gameLoop());
    }
    
    update() {
        this.gameTime++;
        
        // Player movement
        let moveX = this.joystickX;
        let moveY = this.joystickY;
        
        // Apply movement
        if (moveX !== 0 || moveY !== 0) {
            const speed = this.player.speed;
            this.player.x += moveX * speed;
            this.player.y += moveY * speed;
        }
        
        // Boundaries
        this.player.x = Math.max(0, Math.min(this.canvas.width - this.player.width, this.player.x));
        this.player.y = Math.max(0, Math.min(this.canvas.height - this.player.height, this.player.y));
        
        // Update enemies (simple AI)
        this.enemies.forEach(enemy => {
            if (!enemy.alive) return;
            
            enemy.x += (Math.random() - 0.5) * enemy.speed;
            enemy.y += (Math.random() - 0.5) * enemy.speed;
            
            // Boundaries
            enemy.x = Math.max(0, Math.min(this.canvas.width - enemy.width, enemy.x));
            enemy.y = Math.max(0, Math.min(this.canvas.height - enemy.height, enemy.y));
        });
        
        // Update bullets
        this.bullets.forEach((bullet, index) => {
            bullet.y -= 10;
            
            // Check collisions
            this.enemies.forEach(enemy => {
                if (enemy.alive && this.checkCollision(bullet, enemy)) {
                    enemy.health -= this.player.weapon.damage;
                    if (enemy.health <= 0) {
                        enemy.alive = false;
                        this.player.kills++;
                        GAME.player.kills = this.player.kills;
                    }
                    this.bullets.splice(index, 1);
                }
            });
            
            // Remove out of bounds
            if (bullet.y < 0) this.bullets.splice(index, 1);
        });
        
        // Zone shrinking
        if (this.gameTime % 600 === 0 && this.zoneRadius > 100) {
            this.zoneRadius -= 20;
        }
        
        // Update UI
        this.updateUI();
        
        // Check game end
        const alive = this.enemies.filter(e => e.alive).length;
        if (alive === 0) {
            this.endGame(true);
        }
        
        if (this.player.health <= 0) {
            this.endGame(false);
        }
    }
    
    render() {
        // Clear canvas
        this.ctx.fillStyle = '#0a0f1a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw grid
        this.ctx.strokeStyle = 'rgba(255,255,255,0.05)';
        for (let x = 0; x < this.canvas.width; x += 50) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, this.canvas.height);
            this.ctx.stroke();
        }
        
        // Draw zone
        this.ctx.strokeStyle = 'rgba(255, 215, 0, 0.5)';
        this.ctx.lineWidth = 3;
        this.ctx.beginPath();
        this.ctx.arc(this.canvas.width/2, this.canvas.height/2, this.zoneRadius, 0, Math.PI * 2);
        this.ctx.stroke();
        
        // Draw enemies
        this.enemies.forEach(enemy => {
            if (enemy.alive) {
                this.ctx.fillStyle = enemy.character.color;
                this.ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);
                
                // Head
                this.ctx.beginPath();
                this.ctx.arc(enemy.x + enemy.width/2, enemy.y, 15, 0, Math.PI * 2);
                this.ctx.fill();
            }
        });
        
        // Draw player
        this.ctx.fillStyle = this.player.character.color;
        this.ctx.fillRect(this.player.x, this.player.y, this.player.width, this.player.height);
        
        // Player head
        this.ctx.beginPath();
        this.ctx.arc(this.player.x + this.player.width/2, this.player.y, 18, 0, Math.PI * 2);
        this.ctx.fill();
        
        // Draw bullets
        this.ctx.fillStyle = '#ffd700';
        this.bullets.forEach(bullet => {
            this.ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
        });
    }
    
    shoot() {
        if (this.player.reloading || this.player.weapon.ammo <= 0) {
            if (this.player.weapon.ammo <= 0) {
                this.reload();
            }
            return;
        }
        
        this.bullets.push({
            x: this.player.x + this.player.width / 2,
            y: this.player.y,
            width: 5,
            height: 10
        });
        
        this.player.weapon.ammo--;
        this.updateAmmo();
    }
    
    reload() {
        if (this.player.reloading) return;
        
        this.player.reloading = true;
        this.player.weapon.ammo = 0;
        this.updateAmmo();
        
        setTimeout(() => {
            this.player.reloading = false;
            this.player.weapon.ammo = this.player.weapon.maxAmmo;
            this.updateAmmo();
        }, 2000);
    }
    
    updateAmmo() {
        document.getElementById('ammoCount').textContent = 
            `${this.player.weapon.ammo}/${this.player.weapon.maxAmmo}`;
    }
    
    checkCollision(bullet, enemy) {
        return bullet.x > enemy.x && 
               bullet.x < enemy.x + enemy.width &&
               bullet.y > enemy.y && 
               bullet.y < enemy.y + enemy.height;
    }
    
    updateUI() {
        // Health
        const healthPercent = (this.player.health / this.player.maxHealth) * 100;
        document.getElementById('healthFill').style.width = `${healthPercent}%`;
        document.getElementById('healthText').textContent = 
            `${Math.floor(this.player.health)}/${this.player.maxHealth}`;
        
        // Stats
        document.getElementById('hudKills').textContent = this.player.kills;
        
        const alive = this.enemies.filter(e => e.alive).length + 1;
        document.getElementById('hudAlive').textContent = alive;
        document.getElementById('hudRank').textContent = `#${alive}`;
    }
    
    endGame(victory) {
        this.stop();
        
        if (victory) {
            GAME.player.wins++;
            GAME.player.gold += 500;
            GAME.player.level++;
        }
        
        // Show results
        alert(victory ? `VICTORY! ${this.player.kills} kills! +500 Gold` : "DEFEAT! Try again!");
        showScreen('mainMenu');
    }
}

// Setup Controls
function setupControls() {
    // Keyboard
    window.addEventListener('keydown', (e) => {
        if (e.key === ' ' || e.key === 'f') {
            if (gameEngine) gameEngine.shoot();
        }
        if (e.key === 'r') {
            if (gameEngine) gameEngine.reload();
        }
    });
    
    // Mobile buttons
    document.getElementById('shootBtn').addEventListener('touchstart', (e) => {
        e.preventDefault();
        if (gameEngine) gameEngine.shoot();
    });
    
    document.getElementById('reloadBtn').addEventListener('touchstart', (e) => {
        e.preventDefault();
        if (gameEngine) gameEngine.reload();
    });
    
    document.getElementById('jumpBtn').addEventListener('touchstart', (e) => {
        e.preventDefault();
        // Jump action
        if (gameEngine) {
            // Add jump logic here
        }
    });
}

// Start Game
function startGame() {
    showScreen('gameScreen');
    gameEngine = new GameEngine();
    gameEngine.start();
}

// Shop Functions
function buyWeapon(weaponId) {
    const weapon = GAME.weapons.find(w => w.id === weaponId);
    if (GAME.player.gold >= weapon.price) {
        GAME.player.gold -= weapon.price;
        alert(`Purchased ${weapon.name}!`);
        // Update UI
    } else {
        alert("Not enough gold!");
    }
}

// Settings Functions
function toggleSound() {
    GAME.state.soundEnabled = !GAME.state.soundEnabled;
}

function toggleVibration() {
    GAME.state.vibrationEnabled = !GAME.state.vibrationEnabled;
}const CACHE_NAME = 'free-fire-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/style.css',
  '/game.js',
  '/manifest.json',
  '/icon.png'
];

// Install Service Worker
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(ASSETS))
  );
});

// Fetch from cache or network
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => response || fetch(event.request))
  );
});

// Update cache
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => 
      Promise.all(
        keys.filter(key => key !== CACHE_NAME)
          .map(key => caches.delete(key))
      )
    )
  );
});const fs = require('fs');
const archiver = require('archiver');

const output = fs.createWriteStream('free-fire-game.zip');
const archive = archiver('zip');

output.on('close', () => {
    console.log('ZIP created: ' + archive.pointer() + ' bytes');
});

archive.pipe(output);

// Add files
archive.file('index.html', {name: 'index.html'});
archive.file('style.css', {name: 'style.css'});
archive.file('game.js', {name: 'game.js'});
archive.file('manifest.json', {name: 'manifest.json'});
archive.file('service-worker.js', {name: 'service-worker.js'});
archive.file('README.txt', {name: 'README.txt'});

archive.finalize();